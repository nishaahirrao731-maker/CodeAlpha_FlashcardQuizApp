# CodeAlpha_FlashcardQuizApp

**Task 1 — Flashcard Quiz App** | CodeAlpha App Development Internship

A flashcard app for studying, with full customization support.

## Features

- **Question/answer flashcards** — question on the front, "Show Answer" button reveals the answer on the back
- **Next / Previous navigation** — move through the deck in either direction
- **Add, edit, delete** — fully customize your own deck of cards
- **Preloaded sample deck** — three starter cards so the app isn't empty on first run
- **Clean, minimal UI** — responsive, with light and dark mode support

## Tech stack

HTML, CSS and vanilla JavaScript. No build step, no dependencies. Cards are saved with the browser `localStorage` API.

## How to run

Open `index.html` in any modern browser. That's it.

To host it for free, push this repo to GitHub and turn on GitHub Pages under Settings → Pages → Branch: main.

## Project structure

```
CodeAlpha_FlashcardQuizApp/
├── index.html    # complete app (markup, styles, logic)
└── README.md
```

## Author

Submitted as part of the CodeAlpha App Development Internship.
